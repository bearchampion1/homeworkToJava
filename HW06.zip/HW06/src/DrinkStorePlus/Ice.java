package DrinkStorePlus;

/*  Ice �`�@ 5 pt.  */
public enum Ice {
    REGULAR(10, "���`�B"),
    LITTLE(7, "�֦B"),
    LESS(3, "�L�B"),
    FREE(0, "�h�B");

    private int level;
    private String description;
    /* �غc�� Start (5pt.) */
    
    /* �غc�� End (5pt.) */

    public String getDescription() {
        return description;
    }

}
