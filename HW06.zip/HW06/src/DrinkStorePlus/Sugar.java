package DrinkStorePlus;

/*  Sugar �`�@ 5 pt.  */
public enum Sugar {
    REGULAR(10, "���`�}"),
    LESS(7, "�ֿ}"),
    HALF(5, "�b�}"),
    QUARTER(3, "�L�}"),
    FREE(0, "�L�}");

    private final int level;
    private final String description;
    /* �غc�� Start (5pt., 3) */
    Sugar(int level, String description) {
        this.level = level;
        this.description = description;
    }
    /* �غc�� End (5pt.) */

    public String getDescription() {
        return description;
    }

}